Tiny Trawler — media for game coverage

Steam: https://store.steampowered.com/app/3613220/Tiny_Trawler/
Developer: Mathias (solo developer)
Platform: Windows, 64-bit
Status: Coming soon. No release date or price announced here.
Languages: English, Norwegian, Simplified Chinese, Japanese

Start with a handline on a Norwegian harbour dock and grow your own fishing fleet. Discover 55 species, follow harbour rumours, set nets and sail home under lantern light. A cozy fishing game with a business to build, at your own pace.

Included: five screenshots from the current test build, this fact sheet,
and a screenshot caption list. Some screenshots show Norwegian interface text.
Screenshots are staged in the game engine; they are not a continuous first session.
These are preview assets, and the final release may change.

Trailer and portrait clips can be downloaded from the press page.
The local test demo is not a publicly released Steam demo.
No release keys, contact address or access promises are supplied in this package.
